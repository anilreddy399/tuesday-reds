

var url = "http://localhost:3100/Vendors/list/";

$.ajax({
	type : "GET",
	url : url,
	dataType : "json",
	async : false,
	success : function(response) {

		console.log(response);
		var trHTML = '';

		$.each(response, function(i, item) {

			trHTML += '<tr><td>' + item.vendorId + '</td><td>'
					+ item.vendorType.vendorType + '</td><td>'
					+ item.vendorName + '</td></tr>';

			/*'</td><td>'+ item.vendorCompanyRegistrationNo+*/
		});

		$('#records_table').append(trHTML);

	}

});
